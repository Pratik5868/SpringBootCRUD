package com.example.studmanage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.studmanage.entity.Student;
import com.example.studmanage.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	public StudentRepository studrepo;

	@Override
	public String saveStudent(Student st) {
		this.studrepo.save(st);
		return "Save the student";
		
	}

	@Override
	public List<Student> getStudent() {
		System.out.println("Bhej diye bhai student");
		return this.studrepo.findAll();
	}

	@Override
	public void deleteStudent(int studId) {
		this.studrepo.deleteById(studId);
		
	}
	
	

}

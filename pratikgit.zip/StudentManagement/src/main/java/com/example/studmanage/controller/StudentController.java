package com.example.studmanage.controller;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.studmanage.entity.Student;
import com.example.studmanage.service.StudentService;

@RestController
public class StudentController {
	
	@Autowired
	public StudentService studservice;
	
	@PostMapping("/savestudent")
	public String studSave(@RequestParam(name = "studId") int Id, @RequestParam(value="studName") String name
			,@RequestParam(name="city") String city) 
	{
		Student st = new Student(Id,name,city);
		return this.studservice.saveStudent(st);
	}
	
	
	@GetMapping("/getstudent")
	public List<Student> studGet(){
		return this.studservice.getStudent();
	}
	
	@DeleteMapping("/deletestudent")
	public String delStudent(@RequestParam(name="studId")int studId) {
		this.studservice.deleteStudent(studId);
		return "Student with ID:-"+studId+"is deleted successfully";
	}

}

package com.example.studmanage.service;

import java.util.List;

import com.example.studmanage.entity.Student;

public interface StudentService {
	public String saveStudent(Student st);
	public List<Student> getStudent();
    public void deleteStudent(int studId);
}
